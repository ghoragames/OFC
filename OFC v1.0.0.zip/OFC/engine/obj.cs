﻿using System;
using System.Collections.Generic;
using System.Text;
using SFML.Graphics;
using SFML.System;

namespace engline
{
    internal class Obj
    {
        public RectangleShape rectangle;

        public Obj(Vector2f Pos, Vector2f Size, Color color) 
        {
            rectangle = new RectangleShape()
            {
                Size = Size,
                FillColor = color,
                Position = Pos,
            };
        }
    }
}
