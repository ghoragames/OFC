﻿using SFML;
using SFML.Graphics;
using SFML.System;
using SFML.Window;
using System;
using System.Collections.Generic;
using System.Text;

namespace engline
{
    public class Engine
    {
        static void Draw(Obj obj, Vector2f Pos, Vector2f Size, Color color, RenderWindow window)
        {
            obj = new Obj(Pos, Size, color);
            window.Draw(obj.rectangle);
        }

        static void Main(string[] args)
        {
            RenderWindow window = new RenderWindow(new VideoMode(800, 600), "Engine");
            Obj obj = new Obj(new Vector2f(0,0), new Vector2f(0,0), Color.White);

            window.SetFramerateLimit(60);

            window.Closed += (obj, e) => window.Close();
            window.Resized += (obj, e) => { window.Size.X.Equals(e.Width); window.Size.Y.Equals(e.Height); };

            

            while (window.IsOpen)
            {
                window.DispatchEvents();

                Draw(obj, new Vector2f(window.Size.X / 2, window.Size.Y / 2), new Vector2f(100, 100), Color.Red, window);

                window.Display();
            }
        }
    }
}
