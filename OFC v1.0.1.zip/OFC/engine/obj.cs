﻿using System;
using System.Collections.Generic;
using System.Text;
using SFML.Graphics;
using SFML.System;

namespace engline
{
    internal class Obj
    {
        public RectangleShape rectangle;

        public Obj(Vector2f Pos, Vector2f Size, Color color) 
        {
            rectangle = new RectangleShape()
            {
                Size = Size,
                FillColor = color,
                Position = Pos,
            };
        }
    }

    public class SpriteObj
    {
        public Sprite sprite;
        public Texture texture;

        public SpriteObj(string texturePath)
        {
            try
            {
                texture = new Texture(texturePath); // Загружаем текстуру из файла
                sprite = new Sprite(texture);
            }
            catch (SFML.LoadingFailedException ex)
            {
                Console.WriteLine("Ошибка загрузки текстуры: " + ex.Message);
                // Можно загрузить запасную текстуру (например, красный квадрат)
                texture = null;
                sprite = null;
            }
        }

        // Конструктор с позицией и масштабом
        public SpriteObj(string texturePath, Vector2f position, Vector2f scale)
            : this(texturePath)
        {
            if (sprite != null)
            {
                sprite.Position = position;
                sprite.Scale = scale;
            }
        }
    }
}
