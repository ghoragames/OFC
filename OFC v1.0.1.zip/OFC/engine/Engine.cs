﻿using SFML;
using SFML.Graphics;
using SFML.System;
using SFML.Window;
using System;
using System.Collections.Generic;
using System.Text;

namespace engline
{
    public class Engine
    {
        static void Draw(Obj obj, Vector2f Pos, Vector2f Size, Color color, RenderWindow window)
        {
            obj = new Obj(Pos, Size, color);
            window.Draw(obj.rectangle);
        }

        static void DrawText(string text, Vector2f position, uint characterSize, Color color, Font font, RenderWindow window)
        {
            Text sfText = new Text(text, font, characterSize);
            sfText.Position = position;
            sfText.FillColor = color;
            window.Draw(sfText);
        }

        static void DrawTex(SpriteObj sprite, Vector2f position, RenderWindow window)
        {
            sprite.sprite.Position = position;
            window.Draw(sprite.sprite);
            
        }

        static void Main(string[] args)
        {
            RenderWindow window = new RenderWindow(new VideoMode(800, 600), "Engine");
            Obj obj = new Obj(new Vector2f(0,0), new Vector2f(0,0), Color.White);
            SpriteObj sprite1 = new SpriteObj("Square_Blue.png");
            Font font = new Font("PressStart2P-Regular.ttf");

            window.SetFramerateLimit(60);

            window.Closed += (obj, e) => window.Close();
            window.Resized += (obj, e) => { window.SetView(new View(new FloatRect(0,0,e.Width,e.Height))); };

            

            while (window.IsOpen)
            {
                window.Clear();

                window.DispatchEvents();

                Draw(obj, new Vector2f(20, 20), new Vector2f(50,50), Color.Red, window);
                DrawTex(sprite1, new Vector2f(window.Size.X / 2, window.Size.Y / 2), window);
                DrawText("Hello", new Vector2f(10, 100), 20, Color.Yellow, new Font(font), window);

                window.Display();
            }
        }
    }
}
